# Employee management system

 :briefcase: This is a useful app for industries to manage their **employees**.

Using this app you can crete an employee and add characteristics like the name, the phone number, the address and the department that an employee works.

There is also a table where you can see all the members of your company and also update their information or delete a member :magic_wand: .

_for the installation part and all the dependencies please check the **pachage.json** file._

## Creators ##
* Hamed Bahadori
* Ilhan Karadag
* Dimitra Giannouli


